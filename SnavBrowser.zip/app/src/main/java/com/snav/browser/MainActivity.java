package com.snav.browser;

import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DialogFragment;
import android.app.Fragment;
import android.app.FragmentManager;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.*;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;

public class MainActivity extends Activity {
	
	private Timer _timer = new Timer();
	
	private double toque = 0;
	
	private LinearLayout linear1;
	private LinearLayout linear_b;
	private LinearLayout tela1;
	private LinearLayout tela_pesquisa;
	private LinearLayout tela2;
	private LinearLayout tela3;
	private TextView text_icon;
	private LinearLayout linear_barra_pesquisa;
	private TextView text_pesquisar;
	private LinearLayout linear79;
	private LinearLayout linear_pesquisa;
	private EditText edittext1;
	private ImageView pesquisar;
	private LinearLayout linear20;
	private LinearLayout linear_tela2_base;
	private LinearLayout vazio;
	private WebView webview;
	private LinearLayout linear_mensagem;
	private LinearLayout linear_primeira_pesquisa;
	private ImageView imageview89;
	private TextView text1;
	private ImageView imageview90;
	private TextView text2;
	private ScrollView vscroll1;
	private LinearLayout linear33;
	private LinearLayout linear_tela3_base;
	private LinearLayout linearmenu2;
	private LinearLayout linear_tartaruga_pro;
	private LinearLayout linear_escurecer;
	private LinearLayout linear_JavaScript;
	private LinearLayout linear_limpar_dados2;
	private HorizontalScrollView hscroll1;
	private LinearLayout linear25;
	private LinearLayout linear_copiar_URL;
	private LinearLayout linear_tradutor_google;
	private LinearLayout linear_modo_leitura;
	private LinearLayout linear_resumo_completo;
	private LinearLayout linear_abrir_no_navegador;
	private ImageView imageview57;
	private TextView text14;
	private ImageView imageview63;
	private TextView text19;
	private ImageView imageview92;
	private TextView text7;
	private ImageView imageview94;
	private TextView text12;
	private ImageView imageview58;
	private TextView text15;
	private LinearLayout linear72;
	private LinearLayout linear_texto_remumo;
	private TextView text_icon_tartaruga;
	private ImageView fecha;
	private ImageView IA;
	private ImageView copia;
	private TextView text11;
	private CheckBox checkbox_brilho;
	private CheckBox checkbox_javascript2;
	private TextView text5;
	private LinearLayout linear23;
	private LinearLayout linear_bar_pesq;
	private ImageView more;
	private TextView text_barra;
	private ProgressBar prog;
	
	private Intent intent = new Intent();
	private SharedPreferences Dados;
	private AlertDialog.Builder Limpar_Dialog;
	private TimerTask time;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.main);
		initialize(_savedInstanceState);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear_b = findViewById(R.id.linear_b);
		tela1 = findViewById(R.id.tela1);
		tela_pesquisa = findViewById(R.id.tela_pesquisa);
		tela2 = findViewById(R.id.tela2);
		tela3 = findViewById(R.id.tela3);
		text_icon = findViewById(R.id.text_icon);
		linear_barra_pesquisa = findViewById(R.id.linear_barra_pesquisa);
		text_pesquisar = findViewById(R.id.text_pesquisar);
		linear79 = findViewById(R.id.linear79);
		linear_pesquisa = findViewById(R.id.linear_pesquisa);
		edittext1 = findViewById(R.id.edittext1);
		pesquisar = findViewById(R.id.pesquisar);
		linear20 = findViewById(R.id.linear20);
		linear_tela2_base = findViewById(R.id.linear_tela2_base);
		vazio = findViewById(R.id.vazio);
		webview = findViewById(R.id.webview);
		webview.getSettings().setJavaScriptEnabled(true);
		webview.getSettings().setSupportZoom(true);
		linear_mensagem = findViewById(R.id.linear_mensagem);
		linear_primeira_pesquisa = findViewById(R.id.linear_primeira_pesquisa);
		imageview89 = findViewById(R.id.imageview89);
		text1 = findViewById(R.id.text1);
		imageview90 = findViewById(R.id.imageview90);
		text2 = findViewById(R.id.text2);
		vscroll1 = findViewById(R.id.vscroll1);
		linear33 = findViewById(R.id.linear33);
		linear_tela3_base = findViewById(R.id.linear_tela3_base);
		linearmenu2 = findViewById(R.id.linearmenu2);
		linear_tartaruga_pro = findViewById(R.id.linear_tartaruga_pro);
		linear_escurecer = findViewById(R.id.linear_escurecer);
		linear_JavaScript = findViewById(R.id.linear_JavaScript);
		linear_limpar_dados2 = findViewById(R.id.linear_limpar_dados2);
		hscroll1 = findViewById(R.id.hscroll1);
		linear25 = findViewById(R.id.linear25);
		linear_copiar_URL = findViewById(R.id.linear_copiar_URL);
		linear_tradutor_google = findViewById(R.id.linear_tradutor_google);
		linear_modo_leitura = findViewById(R.id.linear_modo_leitura);
		linear_resumo_completo = findViewById(R.id.linear_resumo_completo);
		linear_abrir_no_navegador = findViewById(R.id.linear_abrir_no_navegador);
		imageview57 = findViewById(R.id.imageview57);
		text14 = findViewById(R.id.text14);
		imageview63 = findViewById(R.id.imageview63);
		text19 = findViewById(R.id.text19);
		imageview92 = findViewById(R.id.imageview92);
		text7 = findViewById(R.id.text7);
		imageview94 = findViewById(R.id.imageview94);
		text12 = findViewById(R.id.text12);
		imageview58 = findViewById(R.id.imageview58);
		text15 = findViewById(R.id.text15);
		linear72 = findViewById(R.id.linear72);
		linear_texto_remumo = findViewById(R.id.linear_texto_remumo);
		text_icon_tartaruga = findViewById(R.id.text_icon_tartaruga);
		fecha = findViewById(R.id.fecha);
		IA = findViewById(R.id.IA);
		copia = findViewById(R.id.copia);
		text11 = findViewById(R.id.text11);
		checkbox_brilho = findViewById(R.id.checkbox_brilho);
		checkbox_javascript2 = findViewById(R.id.checkbox_javascript2);
		text5 = findViewById(R.id.text5);
		linear23 = findViewById(R.id.linear23);
		linear_bar_pesq = findViewById(R.id.linear_bar_pesq);
		more = findViewById(R.id.more);
		text_barra = findViewById(R.id.text_barra);
		prog = findViewById(R.id.prog);
		Dados = getSharedPreferences("Dados", Activity.MODE_PRIVATE);
		Limpar_Dialog = new AlertDialog.Builder(this);
		
		linear_barra_pesquisa.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				tela1.setVisibility(View.GONE);
				tela_pesquisa.setVisibility(View.VISIBLE);
				tela2.setVisibility(View.GONE);
				tela3.setVisibility(View.GONE);
			}
		});
		
		pesquisar.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("")) {
					
				} else {
					String input = edittext1.getText().toString().trim();
					String url;
					
					if (input.matches("^(http|https)://.*")) {
						url = input;
					} else {
						try {
							url = "https://www.google.com/search?q=" +
							java.net.URLEncoder.encode(input, "UTF-8");
						} catch (Exception e) {
							url = "https://www.google.com/search?q=" + input;
						}
					}
					
					webview.loadUrl(url);
					tela1.setVisibility(View.GONE);
					tela_pesquisa.setVisibility(View.GONE);
					tela2.setVisibility(View.VISIBLE);
					tela3.setVisibility(View.GONE);
					vazio.setVisibility(View.GONE);
					edittext1.setText("");
					Dados.edit().putString("vazio", "desativado").commit();
					Animation fadeInAnimation = AnimationUtils.loadAnimation(getApplicationContext(), android.R.anim.fade_in);
					fadeInAnimation.setDuration(1000); // Animação suave e lenta
					tela2.startAnimation(fadeInAnimation);
					
				}
			}
		});
		
		webview.setWebViewClient(new WebViewClient() {
			@Override
			public void onPageStarted(WebView _param1, String _param2, Bitmap _param3) {
				final String _url = _param2;
				
				super.onPageStarted(_param1, _param2, _param3);
			}
			
			@Override
			public void onPageFinished(WebView _param1, String _param2) {
				final String _url = _param2;
				
				super.onPageFinished(_param1, _param2);
			}
		});
		
		linear_primeira_pesquisa.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				tela1.setVisibility(View.VISIBLE);
				tela2.setVisibility(View.GONE);
				tela3.setVisibility(View.GONE);
				Animation fadeInAnimation = AnimationUtils.loadAnimation(getApplicationContext(), android.R.anim.fade_in);
				fadeInAnimation.setDuration(1000); // Animação suave e lenta
				tela1.startAnimation(fadeInAnimation);
				
			}
		});
		
		linear_JavaScript.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear_limpar_dados2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Limpar_Dialog.setTitle("Limpar Dados de Navegação");
				Limpar_Dialog.setMessage("Você deseja limpar todos os dados de navegação?");
				Limpar_Dialog.setPositiveButton("SIM", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface _dialog, int _which) {
						webview.clearCache(true);
						webview.clearHistory();
					}
				});
				Limpar_Dialog.setNegativeButton("NÃO", null);
				
				// Cria e exibe
				final AlertDialog d = Limpar_Dialog.create();
				d.show();
				
				// Customização do Fundo (Cor 34495E e Raio 20)
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
				gd.setColor(0xFF34495E);
				gd.setCornerRadius(20);
				d.getWindow().setBackgroundDrawable(gd);
				
				// Escurecer fundo da tela (Dim)
				d.getWindow().setDimAmount(0.7f);
				
				// Cores dos Botões (Cor 9E9E9E)
				d.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(0xFF9E9E9E);
				d.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(0xFF9E9E9E);
				
				// Ajuste da cor do Título (Branco)
				int titleId = getResources().getIdentifier("alertTitle", "id", "android");
				if (titleId > 0) {
					android.widget.TextView tvTitle = (android.widget.TextView) d.findViewById(titleId);
					if (tvTitle != null) {
						tvTitle.setTextColor(android.graphics.Color.WHITE);
					}
				}
				
				// Ajuste da cor da Mensagem (Branco)
				android.widget.TextView tvMsg = (android.widget.TextView) d.findViewById(android.R.id.message);
				if (tvMsg != null) {
					tvMsg.setTextColor(android.graphics.Color.WHITE);
				}
				
			}
		});
		
		linear_copiar_URL.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "Copiado para a área de transferência");
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", webview.getUrl()));
			}
		});
		
		linear_tradutor_google.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				String url = webview.getUrl();
				if (url != null) {
					webview.loadUrl("https://translate.google.com/translate?sl=en&tl=pt&hl=pt-BR&u=" + url.replace("https://", "") + "&client=webapp");
					SketchwareUtil.showMessage(getApplicationContext(), "Traduzindo");
				} else {
					SketchwareUtil.showMessage(getApplicationContext(), "Nenhuma URL encontrada para traduzir");
				}
				
			}
		});
		
		linear_modo_leitura.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				toque++;
				if ((toque % 2) == 1) {
					linear_modo_leitura.setAlpha((float)(0.5d));
					webview.setWebViewClient(new WebViewClient(){
						@Override
						public void onPageFinished(WebView v, String url){
							String js =
							"javascript:(function(){"
							
							// container principal
							+ "var wrap=document.createElement('div');"
							+ "wrap.style.maxWidth='700px';"
							+ "wrap.style.margin='20px auto';"
							+ "wrap.style.padding='20px';"
							+ "wrap.style.fontFamily='sans-serif';"
							+ "wrap.style.fontSize='21px';"
							+ "wrap.style.lineHeight='1.7';"
							+ "wrap.style.color='#ECF0F1';"
							+ "wrap.style.background='#2C3E50';"
							+ "wrap.style.borderRadius='10px';"
							
							// elementos permitidos
							+ "var els=document.querySelectorAll('p,h1,h2,h3,img');"
							+ "for(var i=0;i<els.length;i++){"
							+ "   var el=els[i].cloneNode(true);"
							
							// imagens
							+ "   if(el.tagName==='IMG'){"
							+ "       var w=els[i].naturalWidth || els[i].width;"
							+ "       var h=els[i].naturalHeight || els[i].height;"
							
							// remove imagens pequenas (ícones inúteis)
							+ "       if(w<=80 || h<=80){ continue; }"
							
							// estilizar imagens
							+ "       el.style.display='block';"
							+ "       el.style.margin='25px auto';"
							+ "       el.style.maxWidth='100%';"
							+ "       el.style.height='auto';"
							+ "       el.style.borderRadius='10px';"
							+ "       el.style.boxShadow='0 0 15px rgba(0,0,0,0.4)';"
							+ "   }"
							
							// adiciona ao container
							+ "   wrap.appendChild(el);"
							+ "}"
							
							// limpar a página
							+ "document.body.innerHTML='';"
							+ "document.body.style.background='#2C3E50';"
							+ "document.body.appendChild(wrap);"
							
							+ "})();";
							
							if(android.os.Build.VERSION.SDK_INT>=19){
								v.evaluateJavascript(js, null);
							} else {
								v.loadUrl(js);
							}
						}
					});
				} else {
					linear_modo_leitura.setAlpha((float)(1.0d));
					webview.setWebViewClient(new WebViewClient(){
						@Override
						public void onPageFinished(WebView v, String url){
							String js =
							"javascript:(function(){"
							// resetando estilo do body
							+ "document.body.style.background='';"
							+ "document.body.style.color='';"
							+ "document.body.style.margin='';"
							+ "document.body.style.maxWidth='';"
							+ "document.body.style.padding='';"
							// mostrando de volta elementos que o modo leitura escondeu
							+ "document.querySelectorAll('header, nav, footer, aside').forEach(e => e.style.display='');"
							+ "})();";
							
							if(android.os.Build.VERSION.SDK_INT >= 19){
								v.evaluateJavascript(js, null);
							} else {
								v.loadUrl(js);
							}
						}
					});
				}
				webview.loadUrl(webview.getUrl());
			}
		});
		
		linear_resumo_completo.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear_abrir_no_navegador.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse(webview.getUrl()));
				startActivity(intent);
			}
		});
		
		fecha.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				text11.setText("");
				linear_tartaruga_pro.setVisibility(View.GONE);
				Animation fadeOutAnimation = AnimationUtils.loadAnimation(getApplicationContext(), android.R.anim.fade_out);
				fadeOutAnimation.setDuration(1000); // Suave e lenta ao contrário
				linear_tartaruga_pro.startAnimation(fadeOutAnimation);
				linear_resumo_completo.setAlpha((float)(1.0d));
				copia.setVisibility(View.GONE);
			}
		});
		
		IA.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final String encoded = "aGZfdUxHQnh0bGNrVUZJZG5vdVRPeEtRZWh1cFdiYmZmdklJbwo=";
				final String HF_API_KEY = new String(android.util.Base64.decode(encoded, android.util.Base64.DEFAULT));
				
				IA.setOnClickListener(new View.OnClickListener() {
					@Override
					public void onClick(View v) {
						IA.setEnabled(false);
						IA.setAlpha(0.5f);
						
						webview.evaluateJavascript("(function(){return document.body.innerText;})();", new ValueCallback<String>() {
							@Override
							public void onReceiveValue(String value) {
								final String conteudo = value.replaceAll("^\"|\"$", "").replace("\\n", "\n");
								
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										text11.setText("Carregando... ⏳\n");
									}
								});
								
								new Thread(new Runnable() {
									@Override
									public void run() {
										String resposta = "Erro na conexão";
										
										try {
											java.net.URL url = new java.net.URL("https://router.huggingface.co/v1/chat/completions");
											java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
											conn.setRequestMethod("POST");
											conn.setRequestProperty("Authorization", "Bearer " + HF_API_KEY);
											conn.setRequestProperty("Content-Type", "application/json");
											conn.setDoOutput(true);
											
											org.json.JSONObject payload = new org.json.JSONObject();
											payload.put("model", "meta-llama/Llama-3.1-8B-Instruct:novita");
											
											org.json.JSONArray messages = new org.json.JSONArray();
											org.json.JSONObject msg = new org.json.JSONObject();
											msg.put("role", "user");
											msg.put("content", "Resuma este texto:\n" + conteudo);
											messages.put(msg);
											
											payload.put("messages", messages);
											payload.put("max_tokens", 1024);
											
											java.io.OutputStream os = conn.getOutputStream();
											os.write(payload.toString().getBytes("UTF-8"));
											os.close();
											
											if (conn.getResponseCode() == 200) {
												java.io.BufferedReader br = new java.io.BufferedReader(
												new java.io.InputStreamReader(conn.getInputStream()));
												StringBuilder sb = new StringBuilder();
												String line;
												while ((line = br.readLine()) != null) {
													sb.append(line);
												}
												br.close();
												
												org.json.JSONObject json = new org.json.JSONObject(sb.toString());
												resposta = json.getJSONArray("choices")
												.getJSONObject(0)
												.getJSONObject("message")
												.getString("content");
											} else {
												resposta = "Erro HTTP: " + conn.getResponseCode();
											}
											conn.disconnect();
										} catch (Exception e) {
											resposta = "Erro: " + e.getMessage();
										}
										
										final String finalResposta = resposta;
										
										runOnUiThread(new Runnable() {
											@Override
											public void run() {
												text11.setText("");
												
												final android.os.Handler handler = new android.os.Handler(android.os.Looper.getMainLooper());
												
												for (int i = 0; i < finalResposta.length(); i++) {
													final int idx = i;
													handler.postDelayed(new Runnable() {
														@Override
														public void run() {
															text11.append(String.valueOf(finalResposta.charAt(idx)));
															
															if (idx == finalResposta.length() - 1) {
																IA.setEnabled(true);
																IA.setAlpha(1.0f);
															}
														}
													}, idx * 10);
												}
												
												if (finalResposta.isEmpty()) {
													text11.setText(finalResposta);
													IA.setEnabled(true);
													IA.setAlpha(1.0f);
												}
											}
										});
									}
								}).start();
							}
						});
					}
				});
			}
		});
		
		copia.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", text11.getText().toString()));
				SketchwareUtil.showMessage(getApplicationContext(), "Copiado para a área de transferência");
			}
		});
		
		checkbox_brilho.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox_brilho.setChecked(true);
					Dados.edit().putString("brilho", "ativado").commit();
					webview.setAlpha((float)(0.5d));
				} else {
					checkbox_brilho.setChecked(false);
					Dados.edit().putString("brilho", "desativado").commit();
					webview.setAlpha((float)(1.0d));
				}
			}
		});
		
		checkbox_javascript2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton _param1, boolean _param2) {
				final boolean _isChecked = _param2;
				if (_isChecked) {
					checkbox_javascript2.setChecked(true);
					Dados.edit().putString("java", "ativado").commit();
					webview.getSettings().setJavaScriptEnabled(true); 
				} else {
					checkbox_javascript2.setChecked(false);
					webview.getSettings().setJavaScriptEnabled(false); 
					Dados.edit().putString("java", "desativado").commit();
				}
			}
		});
		
		linear_bar_pesq.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				tela1.setVisibility(View.GONE);
				tela_pesquisa.setVisibility(View.GONE);
				tela2.setVisibility(View.VISIBLE);
				tela3.setVisibility(View.GONE);
				Animation fadeInAnimation = AnimationUtils.loadAnimation(getApplicationContext(), android.R.anim.fade_in);
				fadeInAnimation.setDuration(1000); // Animação suave e lenta
				tela2.startAnimation(fadeInAnimation);
			}
		});
		
		more.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final android.widget.LinearLayout root = new android.widget.LinearLayout(MainActivity.this);
				root.setOrientation(android.widget.LinearLayout.VERTICAL);
				
				int p = (int) android.util.TypedValue.applyDimension(android.util.TypedValue.COMPLEX_UNIT_DIP, 8, getResources().getDisplayMetrics());
				root.setPadding(p, p, p, p);
				
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
				gd.setColor(android.graphics.Color.parseColor("#34495E"));
				gd.setCornerRadius(20f);
				root.setBackground(gd);
				
				android.graphics.Typeface font;
				try {
					font = android.graphics.Typeface.createFromAsset(getAssets(), "fonts/open_regular.ttf");
				} catch (Exception e) {
					font = android.graphics.Typeface.DEFAULT;
				}
				
				final android.widget.PopupWindow popup = new android.widget.PopupWindow(root,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT,
				android.view.ViewGroup.LayoutParams.WRAP_CONTENT, true);
				
				popup.setElevation(20f);
				popup.setOutsideTouchable(true);
				popup.setFocusable(true);
				
				String[] itens = {"Carregar", "Navegante", "Ferramenta", "Pesquisa"};
				
				for (int i = 0; i < itens.length; i++) {
					
					final int pos = i;
					android.widget.TextView tv = new android.widget.TextView(MainActivity.this);
					tv.setText(itens[i]);
					tv.setTextColor(android.graphics.Color.parseColor("#9E9E9E"));
					tv.setTextSize(16);
					tv.setPadding(50, 30, 50, 30);
					tv.setTypeface(font, 0);
					tv.setClickable(true);
					
					android.util.TypedValue outValue = new android.util.TypedValue();
					MainActivity.this.getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
					tv.setBackgroundResource(outValue.resourceId);
					
					tv.setOnClickListener(new android.view.View.OnClickListener() {
						@Override
						public void onClick(android.view.View v) {
							
							android.view.animation.Animation anim = android.view.animation.AnimationUtils.loadAnimation(MainActivity.this, android.R.anim.fade_in);
							anim.setDuration(1000);
							
							switch (pos) {
								
								case 0:
								webview.loadUrl(webview.getUrl());
								break;
								
								case 1:
								tela1.setVisibility(android.view.View.VISIBLE);
								tela2.setVisibility(android.view.View.GONE);
								tela3.setVisibility(android.view.View.GONE);
								tela_pesquisa.setVisibility(android.view.View.GONE);
								tela1.startAnimation(anim);
								break;
								
								case 2:
								tela1.setVisibility(android.view.View.GONE);
								tela2.setVisibility(android.view.View.GONE);
								tela3.setVisibility(android.view.View.VISIBLE);
								tela_pesquisa.setVisibility(android.view.View.GONE);
								tela3.startAnimation(anim);
								break;
								
								case 3:
								tela1.setVisibility(android.view.View.GONE);
								tela_pesquisa.setVisibility(android.view.View.VISIBLE);
								tela2.setVisibility(android.view.View.GONE);
								tela3.setVisibility(android.view.View.GONE);
								tela_pesquisa.startAnimation(anim);
								break;
								
							}
							
							popup.dismiss();
						}
					});
					
					root.addView(tv);
				}
				
				root.measure(android.view.View.MeasureSpec.UNSPECIFIED, android.view.View.MeasureSpec.UNSPECIFIED);
				
				int xOffset = -(root.getMeasuredWidth() - _view.getWidth());
				int yOffset = -(root.getMeasuredHeight() + _view.getHeight());
				
				popup.showAsDropDown(_view, xOffset, yOffset);
			}
		});
	}
	
	private void initializeLogic() {
		_armazenamento();
		_open_sans();
		_interfaces();
		_download();
		_internet();
		_gone();
	}
	
	@Override
	public void onBackPressed() {
		if (webview.canGoBack()) {
			webview.goBack();
		} else {
			tela1.setVisibility(View.VISIBLE);
			tela_pesquisa.setVisibility(View.GONE);
			tela2.setVisibility(View.GONE);
			tela3.setVisibility(View.GONE);
			toque++;
			if (toque == 1) {
				time = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								toque = 0;
							}
						});
					}
				};
				_timer.schedule(time, (int)(2000));
				SketchwareUtil.showMessage(getApplicationContext(), "Pressione novamente para sair.");
			} else {
				finish();
			}
		}
	}
	public void _gone() {
		//visibilidade
		//telas
		tela_pesquisa.setVisibility(View.GONE);
		tela2.setVisibility(View.GONE);
		tela3.setVisibility(View.GONE);
		linear_resumo_completo.setVisibility(View.GONE);
		//IA
		linear_tartaruga_pro.setVisibility(View.GONE);
		copia.setVisibility(View.GONE);
		//linear b
		linear_b.post(new Runnable() {
			@Override
			public void run() {
				
				final int ALTURA = linear_b.getHeight();
				
				webview.setOnScrollChangeListener(new android.view.View.OnScrollChangeListener() {
					
					private int ultimoScroll = 0;
					private boolean barraVisivel = true;
					
					@Override
					public void onScrollChange(android.view.View v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {
						
						int diff = scrollY - ultimoScroll;
						ultimoScroll = scrollY;
						
						// Scroll descendo → esconder
						if (diff > 0 && barraVisivel) {
							linear_b.animate()
							.translationY(ALTURA)
							.setDuration(200)
							.withEndAction(new Runnable() {
								@Override
								public void run() {
									linear_b.setVisibility(android.view.View.GONE);
								}
							})
							.start();
							barraVisivel = false;
						}
						
						// Scroll subindo → mostrar
						else if (diff < 0 && !barraVisivel) {
							linear_b.setVisibility(android.view.View.VISIBLE);
							linear_b.animate()
							.translationY(0)
							.setDuration(200)
							.start();
							barraVisivel = true;
						}
						
						// Se chegou no topo, garante que esteja visível
						if (scrollY <= 0 && !barraVisivel) {
							linear_b.setVisibility(android.view.View.VISIBLE);
							linear_b.setTranslationY(0);
							barraVisivel = true;
						}
					}
				});
			}
		});
	}
	
	
	public void _open_sans() {
		//fonte
		text_icon_tartaruga.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_sans_bold.ttf"), 0);
		text_pesquisar.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		text_barra.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		edittext1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		text_icon.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_sans_bold.ttf"), 0);
		//text
		text1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		text2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		text5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		text7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		text11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		text12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		text14.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		text15.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		text19.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		//checkbox
		checkbox_javascript2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
		checkbox_brilho.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/open_regular.ttf"), 0);
	}
	
	
	public void _interfaces() {
		// PARA INTERFACE
		// linear barra pesquisa
		int[] colorsCRNTL = { Color.parseColor("#34495E"), Color.parseColor("#34495E") };
		android.graphics.drawable.GradientDrawable CRNTL = new android.graphics.drawable.GradientDrawable(
		android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNTL
		);
		CRNTL.setCornerRadii(new float[]{20, 20, 20, 20, 20, 20, 20, 20});
		CRNTL.setStroke(0, Color.parseColor("#9E9E9E"));
		linear_barra_pesquisa.setElevation(0);
		linear_barra_pesquisa.setBackground(CRNTL);
		
		// vscroll1
		vscroll1.setVerticalScrollBarEnabled(false); vscroll1.setHorizontalScrollBarEnabled(false);
		// hscroll1
		hscroll1.setVerticalScrollBarEnabled(false); hscroll1.setHorizontalScrollBarEnabled(false);
		// linear pesquisa
		int[] colorsCRNHM = { Color.parseColor("#34495E"), Color.parseColor("#34495E") }; android.graphics.drawable.GradientDrawable CRNHM = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM, colorsCRNHM);
		CRNHM.setCornerRadii(new float[]{(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20,(int)20});
		CRNHM.setStroke((int) 0, Color.parseColor("#000000"));
		linear_pesquisa.setElevation((float) 0);
		linear_pesquisa.setBackground(CRNHM);
		
		
	}
	
	
	public void _internet() {
		// Barra de progresso
		final View prog = findViewById(R.id.prog);
		prog.setPivotX(0);
		prog.setScaleX(0f);
		
		// Cookies
		android.webkit.CookieManager cookieManager = android.webkit.CookieManager.getInstance();
		cookieManager.setAcceptCookie(true);
		if (android.os.Build.VERSION.SDK_INT >= 21) {
			cookieManager.setAcceptThirdPartyCookies(webview, true);
		}
		
		// Layout WebView
		webview.setScrollBarStyle(View.SCROLLBARS_INSIDE_OVERLAY);
		webview.setVerticalScrollBarEnabled(true);
		webview.setHorizontalScrollBarEnabled(false);
		webview.setLayoutParams(new LinearLayout.LayoutParams(
		ViewGroup.LayoutParams.MATCH_PARENT,
		ViewGroup.LayoutParams.MATCH_PARENT
		));
		
		// Settings
		WebSettings s = webview.getSettings();
		
		// Agente de usuário
		s.setUserAgentString(
		"Mozilla/5.0 (Linux; Android 16; SM-A065M) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"
		);
		
		s.setJavaScriptEnabled(true);
		s.setDomStorageEnabled(true);
		s.setCacheMode(WebSettings.LOAD_DEFAULT);
		s.setSaveFormData(true);
		
		s.setSupportMultipleWindows(true);
		s.setJavaScriptCanOpenWindowsAutomatically(true);
		
		s.setAllowFileAccess(true);
		s.setAllowContentAccess(true);
		
		try {
			s.setSafeBrowsingEnabled(true);
		} catch (Exception e) {}
		
		if (android.os.Build.VERSION.SDK_INT >= 21) {
			s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
		}
		
		s.setLoadsImagesAutomatically(true);
		s.setBlockNetworkImage(false);
		s.setBlockNetworkLoads(false);
		s.setMediaPlaybackRequiresUserGesture(false);
		
		s.setUseWideViewPort(true);
		s.setLoadWithOverviewMode(true);
		
		if (android.os.Build.VERSION.SDK_INT >= 23) {
			try {
				s.setOffscreenPreRaster(true);
			} catch (Exception e) {}
		}
		
		// Clients
		webview.setWebViewClient(new android.webkit.WebViewClient());
		
		webview.setWebChromeClient(new android.webkit.WebChromeClient() {
			
			private View customView;
			private CustomViewCallback customViewCallback;
			private FrameLayout fullscreenContainer;
			
			@Override
			public void onReceivedTitle(WebView v, String t) {
				text_barra.setText(t);
			}
			
			@Override
			public void onProgressChanged(WebView v, int p) {
				prog.setScaleX(p / 100f);
				prog.setVisibility(p == 100 ? View.GONE : View.VISIBLE);
			}
			
			@Override
			public void onShowCustomView(View v, CustomViewCallback cb) {
				if (customView != null) {
					cb.onCustomViewHidden();
					return;
				}
				
				customView = v;
				customViewCallback = cb;
				
				FrameLayout decor = (FrameLayout) getWindow().getDecorView();
				fullscreenContainer = new FrameLayout(MainActivity.this);
				fullscreenContainer.setBackgroundColor(Color.BLACK);
				fullscreenContainer.addView(v, new FrameLayout.LayoutParams(-1, -1));
				decor.addView(fullscreenContainer);
				
				// fullscreen real (remove barra de navegação)
				decor.setSystemUiVisibility(
				View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
				| View.SYSTEM_UI_FLAG_FULLSCREEN
				| View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
				| View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
				| View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
				);
			}
			
			@Override
			public void onHideCustomView() {
				FrameLayout decor = (FrameLayout) getWindow().getDecorView();
				if (fullscreenContainer != null) {
					decor.removeView(fullscreenContainer);
				}
				
				fullscreenContainer = null;
				customView = null;
				
				// volta UI normal
				decor.setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
				
				if (customViewCallback != null) {
					customViewCallback.onCustomViewHidden();
				}
			}
		});
	}
	
	
	public void _armazenamento() {
		//PARA O ARMAZENAMENTO DE DADOS
		//brilho da tela
		if (Dados.getString("brilho", "").equals("ativado")) {
			checkbox_brilho.setChecked(true);
			webview.setAlpha((float)(0.5d));
		} else {
			
		}
		if (Dados.getString("brilho", "").equals("desativado")) {
			checkbox_brilho.setChecked(false);
			webview.setAlpha((float)(1.0d));
		} else {
			
		}
		//javascript
		if (Dados.getString("java", "").equals("ativado")) {
			checkbox_javascript2.setChecked(true);
			webview.getSettings().setJavaScriptEnabled(true); 
		} else {
			
		}
		if (Dados.getString("java", "").equals("desativado")) {
			checkbox_javascript2.setChecked(false);
			webview.getSettings().setJavaScriptEnabled(false); 
		} else {
			
		}
		//vazio
		if (Dados.getString("vazio", "").equals("desativado")) {
			webview.setWebViewClient(new android.webkit.WebViewClient() {
				@Override
				public void onPageFinished(android.webkit.WebView view, String url) {
					super.onPageFinished(view, url);
					
					String u = view.getUrl();
					
					if (u == null || u.equals("") || u.equals("about:blank")) {
						vazio.setVisibility(android.view.View.VISIBLE);
					} else {
						vazio.setVisibility(android.view.View.GONE);
					}
				}
			});
		} else {
			
		}
	}
	
	
	public void _criação() {
		
	}
	
	
	public void _download() {
		webview.setDownloadListener(new DownloadListener() {
			@Override
			public void onDownloadStart(final String url, final String userAgent, final String contentDisposition, final String mimetype, long contentLength) {
				final String fileName = URLUtil.guessFileName(url, contentDisposition, mimetype);
				
				// Verifica permissão no Sketchware/Android
				if (android.os.Build.VERSION.SDK_INT >= 23) {
					if (checkSelfPermission(android.Manifest.permission.WRITE_EXTERNAL_STORAGE) == android.content.pm.PackageManager.PERMISSION_DENIED) {
						requestPermissions(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
					}
				}
				
				AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
				builder.setTitle("Download");
				builder.setMessage("Deseja baixar o arquivo " + fileName + "?");
				builder.setPositiveButton("Sim", new DialogInterface.OnClickListener() {
					@Override
					public void onClick(DialogInterface dialog, int which) {
						try {
							DownloadManager.Request request = new DownloadManager.Request(Uri.parse(url));
							request.setTitle(fileName);
							request.setDescription("Baixando...");
							request.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
							request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName);
							
							// Adiciona UserAgent e Cookies para evitar erros de 403 Forbidden
							String cookie = android.webkit.CookieManager.getInstance().getCookie(url);
							request.addRequestHeader("Cookie", cookie);
							request.addRequestHeader("User-Agent", userAgent);
							
							DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
							dm.enqueue(request);
							android.widget.Toast.makeText(getApplicationContext(), "Download iniciado...", android.widget.Toast.LENGTH_SHORT).show();
						} catch (Exception e) {
							android.widget.Toast.makeText(getApplicationContext(), "Erro: " + e.getMessage(), android.widget.Toast.LENGTH_SHORT).show();
						}
					}
				});
				builder.setNegativeButton("Não", null);
				
				// Estilo Customizado (Bordas 20, Fundo 34495E, Botões 9E9E9E)
				final AlertDialog d = builder.create();
				d.show();
				
				android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable();
				gd.setColor(0xFF34495E);
				gd.setCornerRadius(20);
				d.getWindow().setBackgroundDrawable(gd);
				d.getWindow().setDimAmount(0.7f);
				
				d.getButton(DialogInterface.BUTTON_POSITIVE).setTextColor(0xFF9E9E9E);
				d.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(0xFF9E9E9E);
				
				// Cor do texto para contraste
				android.widget.TextView tvMsg = (android.widget.TextView) d.findViewById(android.R.id.message);
				if (tvMsg != null) tvMsg.setTextColor(android.graphics.Color.WHITE);
				
				int titleId = getResources().getIdentifier("alertTitle", "id", "android");
				if (titleId > 0) {
					android.widget.TextView tvTitle = (android.widget.TextView) d.findViewById(titleId);
					tvTitle.setTextColor(android.graphics.Color.WHITE);
				}
			}
		});
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}